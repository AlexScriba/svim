{-# LANGUAGE TemplateHaskell #-}

module Menu where

import Brick.AttrMap (attrMap)
import Brick.Main
import Brick.Types
import Brick.Widgets.Core
import Brick.Widgets.Edit (Editor, handleEditorEvent)
import Graphics.Vty (defAttr)
import Graphics.Vty.Input.Events
import Lens.Micro (set)
import Lens.Micro.Extras (view)
import Lens.Micro.Mtl (use, (.=))
import Lens.Micro.TH (makeLenses)
import System.Directory

type ResourceName = String

data MenuState = MenuState
    { _filePaths :: [FilePath]
    }
    deriving (Show)

makeLenses ''MenuState

drawMenu :: MenuState -> [Widget ResourceName]
drawMenu s =
    [ vBox $ map drawPath $ view filePaths s
    ]

drawPath :: FilePath -> Widget n
drawPath = str

handleTuiEvent :: BrickEvent n e -> EventM n MenuState ()
handleTuiEvent e = do
    case e of
        VtyEvent vtye ->
            case vtye of
                EvKey (KChar 'q') [] -> halt
                _other -> continueWithoutRedraw
        _other -> continueWithoutRedraw

app :: App MenuState Event ResourceName
app =
    App
        { appDraw = drawMenu
        , appChooseCursor = showFirstCursor
        , appHandleEvent = handleTuiEvent
        , appStartEvent = return ()
        , appAttrMap = const $ attrMap defAttr []
        }

buildInitialState :: MenuState
buildInitialState =
    MenuState
        [ "project1"
        , "project2"
        , "project3"
        ]

mainFunc :: IO ()
mainFunc = do
    let initialState = buildInitialState
    endState <- defaultMain app initialState
    print endState
