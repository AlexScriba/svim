import Menu

main :: IO ()
main = do
    mainFunc
